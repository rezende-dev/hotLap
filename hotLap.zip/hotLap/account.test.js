const { validateAge } = require('./account.js')

it('idade abaixo de 18', () => {
    expect(validateAge(15)).toBe(false)
})

it('idade igual ou maior de 18', () => {
    expect(validateAge(18)).toBe(true)
})

const { rulesPassword } = require('./account.js')

it('senha com numero', () => {
    expect(rulesPassword('3')).toBe(false)
})

it('senha com letra', () => {
    expect(rulesPassword('d')).toBe(false)
})
it('senha com letra e numero', () => {
    expect(rulesPassword('3d')).toBe(true)
})
const { validatePassword } = require('./account.js')

it('senhas diferentes', () => {
    expect(validatePassword('aa', '11')).toBe(false)
})
it('senhas iguais', () => {
    expect(validatePassword('a1', 'a1')).toBe(true)
})