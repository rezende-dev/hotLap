function validateForm() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var age = document.getElementById("age").value;
    var state = document.getElementById("state").value;
    var city = document.getElementById("city").value;
    var isValid = true;

    // Limpa mensagens de erro
    document.getElementById("nameError").innerHTML = "";
    document.getElementById("emailError").innerHTML = "";
    document.getElementById("passwordError").innerHTML = "";
    document.getElementById("confirmPasswordError").innerHTML = "";
    document.getElementById("ageError").innerHTML = "";
    document.getElementById("stateError").innerHTML = "";
    document.getElementById("cityError").innerHTML = "";

    // Validação do nome
    if (name === "") {
        document.getElementById("nameError").innerHTML = "*Por favor, preencha o nome.";
        isValid = false;
    }

    // Validação do email
    if (email === "") {
        document.getElementById("emailError").innerHTML = "*Por favor, preencha o email.";
        isValid = false;
    } else if (!isValidEmail(email)) {
        document.getElementById("emailError").innerHTML = "*Email inválido.";
        isValid = false;
    }

    // Validação da senha
    if (password === "") {
        document.getElementById("passwordError").innerHTML = "*Por favor, preencha a senha.";
        isValid = false;
    } else if (!isValidPassword(password)) {
        document.getElementById("passwordError").innerHTML = "*A senha deve ter pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas e números.";
        isValid = false;
    }

    // Validação da confirmação da senha
    if (confirmPassword === "") {
        document.getElementById("confirmPasswordError").innerHTML = "*Por favor, digite a senha novamente.";
        isValid = false;
    } else if (password !== confirmPassword) {
        document.getElementById("confirmPasswordError").innerHTML = "*As senhas não coincidem.";
        isValid = false;
    }

    // Validação da idade
    if (age === "" || age < 18) {
        document.getElementById("ageError").innerHTML = "*Você deve ter pelo menos 18 anos para enviar o formulário.";
        isValid = false;
    }

    // Validação do estado
    if (state === "") {
        document.getElementById("stateError").innerHTML = "*Por favor, selecione um estado do Sudeste.";
        isValid = false;
    }

    // Validação da cidade (opcional: pode ser requerida se o estado estiver selecionado)
    if (state !== "" && city === "") {
        document.getElementById("cityError").innerHTML = "*Por favor, escolha uma cidade.";
        isValid = false;
    }

    // Se todas as validações passarem
    if (isValid) {
        document.getElementById("successMessage").style.display = "block"; // Mostra a mensagem de sucesso
        return false; // Impede o envio real do formulário
    } else {
        return false; // Impede o envio real do formulário
    }
}

function isValidEmail(email) {
    // Expressão regular simples para validação de email
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPassword(password) {
    // Senha deve ter pelo menos 8 caracteres, incluindo maiúsculas, minúsculas e números
    var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    return passwordRegex.test(password);
}

function populateCities() {
    var state = document.getElementById("state").value;
    var citySelect = document.getElementById("city");

    // Limpa opções de cidade
    citySelect.innerHTML = '<option value="">Escolha uma cidade</option>';

    // Popula cidades baseado no estado selecionado
    var cities = [];
    if (state === "SP") {
        cities = ["São Paulo", "Campinas", "Santos"];
    } else if (state === "RJ") {
        cities = ["Rio de Janeiro", "Niterói", "Campos dos Goytacazes"];
    } else if (state === "MG") {
        cities = ["Belo Horizonte", "Uberlândia", "Juiz de Fora"];
    } else if (state === "ES") {
        cities = ["Vitória", "Vila Velha", "Cariacica"];
    }

    // Habilita select de cidade e adiciona opções
    innerHTML= citySelect.disabled = false;
    for (var i = 0; i < cities.length; i++) {
        var option = document.createElement("option");
        option.text = cities[i];
        option.value = cities[i];
        citySelect.appendChild(option);
    }
}